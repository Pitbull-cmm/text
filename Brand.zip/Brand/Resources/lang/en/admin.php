<?php
return [
    'table' => [
        'is_active' => 'Status',
    ],
];
