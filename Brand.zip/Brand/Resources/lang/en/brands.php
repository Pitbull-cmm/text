<?php
return [
    'brands' => 'Brands',
    'name' => 'Name',
    'logo' => 'Logo',
    'general' => 'General',
    'form' => [
        'slug' => 'Name',
        'status' => 'Status',
        'enable' => 'Enable the brand',
    ],
];

