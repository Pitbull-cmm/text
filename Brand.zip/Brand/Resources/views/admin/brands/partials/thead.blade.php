<tr>
    @include('admin::partials.table.brand_select_all')

    @php
        $sortBy = request()->get('sort_by', 'id');
        $sort = request()->get('sort', 'asc');
        $newSort = ($sort === 'asc') ? 'desc' : 'asc';
    @endphp

    {{-- Cột ID --}}
    <th>
        <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'id', 'sort' => $sortOrder === 'asc' ? 'desc' : 'asc']) }}">
            {{ trans('admin::admin.table.id') }}
            @if ($sortBy === 'id')
                <span>{{ $sortOrder === 'asc' ? '↑' : '↓' }}</span>
            @endif
        </a>
    </th>

    {{-- Column for Logo --}}
    <th>{{ trans('brand::brands.logo') }}</th>

    {{-- Column for Name --}}
    <th style="width: 32%;" class="dt-orderable-asc dt-orderable-desc" data-dt-column="1">
        <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'name', 'sort' => $newSort]) }}" class="text-decoration-none">
            <span class="dt-column-title">{{ trans('brand::brands.name') }}</span>
            <span class="dt-column-order
                @if($sortBy === 'name') {{ $sort === 'asc' ? 'dt-ordering-asc' : 'dt-ordering-desc' }} @endif">
            </span>
        </a>
    </th>


    {{-- Cột Status --}}
    <th>
        <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'is_active', 'sort' => $sortOrder === 'asc' ? 'desc' : 'asc']) }}">
            {{ trans('admin::admin.table.is_active') }}
            @if ($sortBy === 'is_active')
                <span>{{ $sortOrder === 'asc' ? '↑' : '↓' }}</span>
            @endif
        </a>
    </th>


    {{-- Cột Created At --}}
    <th>
        <a href="{{ request()->fullUrlWithQuery(['sort_by' => 'created_at', 'sort' => $sortOrder === 'asc' ? 'desc' : 'asc']) }}">
            {{ trans('admin::admin.table.created') }}
            @if ($sortBy === 'created_at')
                <span>{{ $sortOrder === 'asc' ? '↑' : '↓' }}</span>
            @endif
        </a>
    </th>
</tr>
