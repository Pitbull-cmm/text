<?php

use App\Models\Brand;
use Illuminate\Support\Facades\Route;
use Modules\Brand\Http\Controllers\Admin\BrandController;

Route::get('brands', [BrandController::class, 'index'])->name('admin.brands.index');
